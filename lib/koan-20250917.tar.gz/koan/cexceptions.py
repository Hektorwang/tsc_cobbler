"""
Custom exceptions for Cobbler

Copyright 2006-2009, Red Hat, Inc and Others
Michael DeHaan <michael.dehaan AT gmail>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
02110-1301  USA
"""


class KoanException(Exception):
    def __init__(self, value, *args):
        if args:
            self.value = value % args
        else:
            self.value = value
        # this is a hack to work around some odd exception handling in older pythons
        self.from_koan = 1

    def __str__(self):
        return repr(self.value)


class KX(KoanException):
    pass


class FileNotFoundException(KoanException):
    pass


class InfoException(Exception):
    """
    Custom exception for tracking of fatal errors.
    """

    def __init__(self, value, *args):
        if args:
            self.value = value % args
        else:
            self.value = value
        self.from_koan = 1

    def __str__(self):
        return repr(self.value)


class VirtCreateException(Exception):
    pass


class OVZCreateException(Exception):
    pass
